import { BrowserRouter, Route, Routes } from "react-router-dom";
import Navbar from "./Webpages/Navbar";
import Data from "./Webpages/Data";
import Register from "./Webpages/Register";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route index path="/" element={<><Navbar/><Data/></>}></Route>
          <Route path="/Register" element={<><Navbar/><Register/></>}></Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
