import axios from 'axios'
import * as types from './Actiontype'


// Get User


 const getUser = (users) =>({
    type:types.GET_USERS,
    payload:users,
 })
 export const get_user=(api)=>{
    return function(dispatch){
        axios.get(api)
        .then((res)=>{
            dispatch(getUser(res.data))
            console.log(res)
        })
        .catch((error)=>{
            console.log(error)
        })
    }
 }


//  Add User


 export const add_user=(api,user)=>{
    return function(){
        axios.post(api,user)
        .then((res)=>{
            console.log(res)
        })
        .catch((error)=>{
            console.log(error)
        })
    }
 }

//  Delete User


export const delete_user=(api)=>{
    return function(){
        axios.delete(api)
    }
}

// Get Single User

const getSingleUser=(user)=>({
    type:types.GET_SINGLE_USER,
    payload:user
})
export const get_single_user=(api)=>{
    return function(dispatch){
        axios.get(api)
        .then((res)=>{
            dispatch(getSingleUser(res.data))
            console.log(res)
        })
        .catch((error)=>{
            console.log(error)
        })
    }
}


// Update user

export const updateUser=(id,user)=>{
    return function(){
        axios.patch(`http://localhost:8000/user/${id}`,user)
        .then((res)=>{
            console.log(res.data)
        })  
        .catch((error)=>{
            console.log(error)
        })
    }
}