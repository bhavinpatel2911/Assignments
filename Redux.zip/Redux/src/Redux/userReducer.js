import * as types from './Actiontype'
const initialState={
    users:[],
    user:{},
    loding:true
}
const userReducer = (state=initialState,action) =>{
    switch(action.type){
        case types.GET_USERS:
            return{
                ...state,
                users:action.payload,
                loding:false
            }
        case types.GET_SINGLE_USER:
            return{
                ...state,
                user:action.payload,
                loding:false
            }
        default:
            return state
    }
}
export default userReducer