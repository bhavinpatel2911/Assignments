import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { delete_user, get_user, get_single_user, updateUser } from '../Redux/Action'
import { useNavigate} from 'react-router-dom'

function Data() {
    let dispatch = useDispatch()

    // Get User


    useEffect(() => {
        dispatch(get_user(`http://localhost:8000/user`))
    }, [])
    let { users } = useSelector((state) => state.data)

    // Delete User

    // let redirect=useNavigate()
    const removeUser = (id) => {
        if (window.confirm("Are You Sure to Delete ?")) {
            dispatch(delete_user(`http://localhost:8000/user/${id}`))
            dispatch(get_user(`http://localhost:8000/user`))
        }
    }

    // Update 

    // Fatch
    useEffect(()=>{
        get_data()
    },[])

    let {user}=useSelector((state)=>state.data)
    let get_data=(id)=>{
        dispatch(get_single_user(`http://localhost:8000/user/${id}`))
    }
    useEffect(()=>{
        setdata({...user})
    },[user])

    // Update
    let redirect=useNavigate()
    const [data,setdata]=useState({
        id:"",
        email:"",
        password:""
    })
    const onchange = (e) =>{
        setdata({...data,[e.target.name]:e.target.value})
    }
    const onsubmit = (id) =>{
        dispatch(updateUser(id,data))
        redirect('/')
    }
    return (
        <div className='mt-5'>
            <table className="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Email</th>
                        <th scope="col">Password</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        users.map((item) => {
                            return (
                                <tr>
                                    <td>{item.id}</td>
                                    <td>{item.email}</td>
                                    <td>{item.password}</td>
                                    <td><button className='btn btn-outline-danger' onClick={() => { removeUser(item.id) }}>DELETE</button><button className='btn btn-outline-success ms-1' data-bs-toggle="modal" data-bs-target="#exampleModal" onClick={()=>{get_data(item.id)}}>UPDATE</button></td>
                                    {/* Modal */}
                                    <div className="modal fade" id="exampleModal" tabIndex={-1} aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div className="modal-dialog">
                                            <div className="modal-content">
                                                <div className="modal-header">
                                                    <h5 className="modal-title" id="exampleModalLabel">Update Ptofile</h5>
                                                    <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" />
                                                </div>
                                                <div className="modal-body">
                                                    <form>
                                                        <div className="mb-3">
                                                            <label htmlFor="exampleInputEmail1" className="form-label">Email address</label>
                                                            <input type="email" className="form-control" value={data.email} onChange={onchange} id="exampleInputEmail1" aria-describedby="emailHelp" name='email' />
                                                            <div id="emailHelp" className="form-text">We'll never share your email with anyone else.</div>
                                                        </div>
                                                        <div className="mb-3">
                                                            <label htmlFor="exampleInputPassword1" className="form-label">Password</label>
                                                            <input type="password" className="form-control" value={data.password} onChange={onchange} id="password" name='password' />
                                                        </div>
                                                    </form>
                                                </div>
                                                <div className="modal-footer">
                                                    <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    <button type="button" className="btn btn-primary" onClick={()=>{onsubmit(item.id)}}>Save changes</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>
        </div>

    )
}

export default Data