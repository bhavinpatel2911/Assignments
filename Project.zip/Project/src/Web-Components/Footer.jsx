import React from 'react'

function Footer() {
  return (
    <div>
        
            {/*Footer Start  */}
            <div className="card text-center">
                <div className="card-header">

                </div>
                <div className="card-body">
                    <h5 className="card-title"><img src="logo.png" style={{ height: "70px" }} alt="" /></h5>
                    <p className="card-text text-dark fw-bold fs-4">Care At Home</p>
                    <input type="text" className="form-control footer-text" style={{ maxWidth: '15rem', margin: "0% auto" }} placeholder="Enter Your Email" aria-label="Enter Your Email" aria-describedby="button-addon2" />
                    <button className="btn text-light mt-2" type="button" style={{ zIndex: 0, backgroundColor: "#8cb573" }} id="button-addon2">Connect</button>

                </div>
                <div className="card-footer text-muted">
                    Copyright &#169; 2023 All rights reserved | This template is made by <b>Bhavin Patel</b>
                </div>
            </div>
            {/* Footer End */}


    </div>
  )
}

export default Footer