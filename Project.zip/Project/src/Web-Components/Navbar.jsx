import React from 'react'
import { NavLink } from 'react-router-dom'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'

function Navbar() {
    let redirect=useNavigate()
    let logout=()=>{
        if(window.confirm("Are you Sure to Logout ?")){
            localStorage.removeItem('id')
            redirect('/')
            toast.success("Logout Successfull !")
        }
    }
    return (
        <div>
            {/* Navbar Start */}
            <div className="container-fluid sticky-top bg-white shadow-sm">
                <div className="container">
                    <nav className="navbar navbar-expand-lg bg-white navbar-light py-3 py-lg-0">
                        <NavLink to='/' className="navbar-brand">
                            <h1 className="m-0 text-uppercase" style={{ color: "#ffb347" }}><img src="logo.png" style={{ height: "70px" }} alt="" />Care At Home</h1>
                        </NavLink>
                        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                            <span className="navbar-toggler-icon" />
                        </button>
                        <div className="collapse navbar-collapse" id="navbarCollapse">
                            <div className="navbar-nav ms-auto py-0">
                                <NavLink to='/' className="nav-item nav-link">Home</NavLink>
                                <NavLink to='/Care' className="nav-item nav-link">Cares</NavLink>
                                <NavLink to='/Appointment' className="nav-item nav-link">Appointmant</NavLink>
                                <NavLink to='/Team' className="nav-item nav-link">Team</NavLink>
                                {
                                    (() => {
                                        if (localStorage.getItem('id')) {
                                            return (
                                                <div className="dropdown mt-lg-4 ms-lg-4" >
                                                    <button className="btn dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false" style={{backgroundColor:"#8cb573",color:"white"}}>
                                                        Welcome {localStorage.getItem('name')}
                                                    </button>
                                                    <ul className="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                                        <li><NavLink className="dropdown-item" to='/Update'>Profile</NavLink></li>
                                                        <li><a className="dropdown-item" onClick={logout} href="javascript:void(0)">Logout</a></li>
                                                    </ul>
                                                </div>
                                            )
                                        }
                                        else{
                                            return(
                                                <NavLink to="/Login" className="nav-item nav-link">Login</NavLink> 
                                            )
                                        }
                                    })()
                                }
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
            {/* Navbar End */}
        </div>

    )
}

export default Navbar