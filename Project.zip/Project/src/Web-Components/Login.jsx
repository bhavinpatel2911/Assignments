import axios from 'axios'
import { data } from 'jquery'
import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'

function Login() {
    let redirect=useNavigate()
    let [formdata,setformdata]=useState({
        id:"",
        email:"",
        password:""
    })
    let onchange=(e)=>{
        setformdata({...formdata,[e.target.name]:[e.target.value]})
    }
    let onsubmit = async(e) =>{
        e.preventDefault()
        await axios.get(`http://localhost:8000/user?email=${formdata.email}`)
        .then((res)=>{
            console.log(res.data)
            if(res.data.length>0){
                if(res.data[0].password==formdata.password){
                    localStorage.setItem('id',res.data[0].id)
                    localStorage.setItem('name',res.data[0].name)
                    localStorage.setItem('address',res.data[0].address)
                    localStorage.setItem('email',res.data[0].email)
                    localStorage.setItem('contact',res.data[0].contact)
                    toast.success("Login Successfull !")
                    redirect('/')
                }
                else if(formdata.password=="" || formdata.password==null){
                    toast.error("Please fill the Password !")
                }
                else{
                    toast.error("Wrong Password !")
                }
            }
            else{
                toast.error("Email not Found !")
                return false
            }
        })
    }
    return (
    <div>
        
        <div className="col-lg-4" style={{margin:"1% auto",boxShadow: "#8cb573 0px 0px 1px 1px"}}>
                            <div className="bg-white text-center rounded p-5">
                                <h1 className="mb-4">Login</h1>
                                <form>
                                    <div className="row g-3">
                                        <div className="col-12 col-sm-6" style={{width:"100%"}}>
                                            <input type="email" className="form-control bg-light border-0" placeholder="Your Email" style={{ height: 55 }} onChange={onchange} value={formdata.email} name='email'/>
                                        </div>
                                        <div className="col-12 col-sm-6" style={{width:"100%"}}>
                                            <input type="password" className="form-control bg-light border-0" placeholder="Your Password" style={{ height: 55 }} onChange={onchange} value={formdata.password} name='password'/>
                                        </div>
                                        <div className="col-12">
                                            <button className="btn w-100 py-3 text-light" onClick={onsubmit} style={{ backgroundColor: "#8cb573" }} type="submit">Login</button>
                                        </div>
                                    </div>
                                    <Link to='/Register' className='mt-1' style={{float:"left"}}>New ? Register Here !</Link>
                                </form>
                            </div>
                        </div>
    </div>
  )
}

export default Login