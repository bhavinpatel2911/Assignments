import React from 'react'
import { Helmet } from 'react-helmet'
import { useNavigate } from 'react-router-dom'

function Dashboard() {
    let redirect=useNavigate()
    let login=()=>{
        redirect('/Login')
    }
    return (
        <div>

            <Helmet>
                <script src="js/main.js"></script>
            </Helmet>

            {/* Hero Start */}
            <div className="container-fluid bg-primary py-5 mb-5 hero-header">
                <div className="container py-5">
                    <div className="row justify-content-start">
                        <div className="col-lg-8 text-center text-lg-start">
                            <h5 className="d-inline-block text-uppercase border-bottom border-5" style={{ color: "#8cb573", borderColor: 'rgba(256, 256, 256, .3) !important' }}>Welcome To Care At Home</h5>
                            <h1 className="display-1 text-white mb-md-4">Best Healthcare Solution In Your Pocket</h1>
                            <div className="pt-2">
                                <a href className="btn btn-light rounded-pill py-md-3 px-md-5 mx-2">Find Doctor</a>
                                <a href className="btn btn-outline-light rounded-pill py-md-3 px-md-5 mx-2">Appointment</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* Hero End */}


            {/* Services Start */}
            <div className="container-fluid py-5">
                <div className="container">
                    <div className="text-center mx-auto mb-5" style={{ maxWidth: 500 }}>
                        <h5 className="d-inline-block text-uppercase border-bottom border-5" style={{ color: "#8cb573" }}>Services</h5>
                        <h1 className="display-4">Healthcare Services</h1>
                    </div>
                    <div className="row g-5">
                        <div className="col-lg-4 col-md-6">
                            <div className="service-item bg-light rounded d-flex flex-column align-items-center justify-content-center text-center">
                                <div className="service-icon mb-4">
                                    <i className="fa fa-2x fa-user-md text-white" />
                                </div>
                                <h4 className="mb-3">Emergency Care</h4>
                                <p className="m-0">Kasd dolor no lorem nonumy sit labore tempor at justo rebum rebum stet, justo elitr dolor amet sit</p>
                                <a className="btn btn-lg rounded-pill" style={{ backgroundColor: "#8cb573" }} href>
                                    <i className="bi bi-arrow-right  text-light" />
                                </a>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                            <div className="service-item bg-light rounded d-flex flex-column align-items-center justify-content-center text-center">
                                <div className="service-icon mb-4">
                                    <i className="fa fa-2x fa-procedures text-white" />
                                </div>
                                <h4 className="mb-3">Operation &amp; Surgery</h4>
                                <p className="m-0">Kasd dolor no lorem nonumy sit labore tempor at justo rebum rebum stet, justo elitr dolor amet sit</p>
                                <a className="btn btn-lg rounded-pill" style={{ backgroundColor: "#8cb573" }} href>
                                    <i className="bi bi-arrow-right text-light" />
                                </a>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                            <div className="service-item bg-light rounded d-flex flex-column align-items-center justify-content-center text-center">
                                <div className="service-icon mb-4">
                                    <i className="fa fa-2x fa-stethoscope text-white" />
                                </div>
                                <h4 className="mb-3">Outdoor Checkup</h4>
                                <p className="m-0">Kasd dolor no lorem nonumy sit labore tempor at justo rebum rebum stet, justo elitr dolor amet sit</p>
                                <a className="btn btn-lg rounded-pill" style={{ backgroundColor: "#8cb573" }} href>
                                    <i className="bi bi-arrow-right  text-light" />
                                </a>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                            <div className="service-item bg-light rounded d-flex flex-column align-items-center justify-content-center text-center">
                                <div className="service-icon mb-4">
                                    <i className="fa fa-2x fa-ambulance text-white" />
                                </div>
                                <h4 className="mb-3">Ambulance Service</h4>
                                <p className="m-0">Kasd dolor no lorem nonumy sit labore tempor at justo rebum rebum stet, justo elitr dolor amet sit</p>
                                <a className="btn btn-lg rounded-pill" style={{ backgroundColor: "#8cb573" }} href>
                                    <i className="bi bi-arrow-right  text-light" />
                                </a>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                            <div className="service-item bg-light rounded d-flex flex-column align-items-center justify-content-center text-center">
                                <div className="service-icon mb-4">
                                    <i className="fa fa-2x fa-pills text-white" />
                                </div>
                                <h4 className="mb-3">Medicine &amp; Pharmacy</h4>
                                <p className="m-0">Kasd dolor no lorem nonumy sit labore tempor at justo rebum rebum stet, justo elitr dolor amet sit</p>
                                <a className="btn btn-lg rounded-pill" style={{ backgroundColor: "#8cb573" }} href>
                                    <i className="bi bi-arrow-right  text-light" />
                                </a>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                            <div className="service-item bg-light rounded d-flex flex-column align-items-center justify-content-center text-center">
                                <div className="service-icon mb-4">
                                    <i className="fa fa-2x fa-microscope text-white" />
                                </div>
                                <h4 className="mb-3">Blood Testing</h4>
                                <p className="m-0">Kasd dolor no lorem nonumy sit labore tempor at justo rebum rebum stet, justo elitr dolor amet sit</p>
                                <a className="btn btn-lg rounded-pill" style={{ backgroundColor: "#8cb573" }} href>
                                    <i className="bi bi-arrow-right text-light" />
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* Services End */}


            {/* Appointment Start */}
            <div className="container-fluid my-5 py-5" style={{ backgroundColor: "#8cb573" }}>
                <div className="container py-5">
                    <div className="row gx-5">
                        <div className="col-lg-6 mb-5 mb-lg-0">
                            <div className="mb-4">
                                <h5 className="d-inline-block text-white text-uppercase border-bottom border-5">Appointment</h5>
                                <h1 className="display-4">Make An Appointment For Your Family</h1>
                            </div>
                            <p className="text-white mb-5">Eirmod sed tempor lorem ut dolores. Aliquyam sit sadipscing kasd ipsum. Dolor ea et dolore et at sea ea at dolor, justo ipsum duo rebum sea invidunt voluptua. Eos vero eos vero ea et dolore eirmod et. Dolores diam duo invidunt lorem. Elitr ut dolores magna sit. Sea dolore sanctus sed et. Takimata takimata sanctus sed.</p>
                            <a className="btn btn-success rounded-pill py-3 px-5 me-3" href>Find Doctor</a>
                            <a className="btn btn-outline-success rounded-pill py-3 px-5" href>Read More</a>
                        </div>
                        <div className="col-lg-6">
                            <div className="bg-white text-center rounded p-5">
                                <h1 className="mb-4">Book An Appointment</h1>
                                <form>
                                    <div className="row g-3">
                                        <div className="col-12 col-sm-6">
                                            <select className="form-select bg-light border-0" style={{ height: 55 }}>
                                                <option selected>Choose Department</option>
                                                <option value={1}>Department 1</option>
                                                <option value={2}>Department 2</option>
                                                <option value={3}>Department 3</option>
                                            </select>
                                        </div>
                                        <div className="col-12 col-sm-6">
                                            <select className="form-select bg-light border-0" style={{ height: 55 }}>
                                                <option selected>Select Doctor</option>
                                                <option value={1}>Doctor 1</option>
                                                <option value={2}>Doctor 2</option>
                                                <option value={3}>Doctor 3</option>
                                            </select>
                                        </div>
                                        <div className="col-12 col-sm-6">
                                            <input type="text" className="form-control bg-light border-0" placeholder="Your Name" style={{ height: 55 }} />
                                        </div>
                                        <div className="col-12 col-sm-6">
                                            <input type="email" className="form-control bg-light border-0" placeholder="Your Email" style={{ height: 55 }} />
                                        </div>
                                        <div className="col-12 col-sm-6">
                                            <div className="date" id="date" data-target-input="nearest">
                                                <input type="time" className="form-control bg-light border-0 datetimepicker-input" placeholder="Date" style={{ height: 55 }} />
                                            </div>
                                        </div>
                                        <div className="col-12 col-sm-6">
                                            <div className="time" id="time" data-target-input="nearest">
                                                <input type="date" className="form-control bg-light border-0 datetimepicker-input" placeholder="Time" style={{ height: 55 }} />
                                            </div>
                                        </div>
                                        <div className="col-12">
                                            {
                                                (()=>{
                                                    if(localStorage.getItem('id')){
                                                        return(
                                                            <button className="btn w-100 py-3 text-light" style={{ backgroundColor: "#8cb573" }} type="submit">Make An Appointment</button>
                                                        )
                                                    }
                                                    else{
                                                        return(
                                                            <button className="btn w-100 py-3 text-light" style={{ backgroundColor: "#8cb573" }} type="submit" onClick={login}>Make An Appointment</button>
                                                        )
                                                    }
                                                })()
                                            }
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* Appointment End */}



            {/* Team Start */}
            <div className="container-fluid py-5">
                <div className="container">
                    <div className="text-center mx-auto mb-5" style={{ maxWidth: 500 }}>
                        <h5 className="d-inline-block text-uppercase border-bottom border-5" style={{ color: "#8cb573" }}>Our Doctors</h5>
                        <h1 className="display-4">Qualified Healthcare Professionals</h1>
                    </div>
                    <div className="owl-carousel team-carousel position-relative">
                        <div className="team-item">
                            <div className="row g-0 bg-light rounded overflow-hidden">
                                <div className="col-12 col-sm-5 h-100">
                                    <img className="img-fluid h-100" src="img/team-1.jpg" style={{ objectFit: 'cover' }} />
                                </div>
                                <div className="col-12 col-sm-7 h-100 d-flex flex-column">
                                    <div className="mt-auto p-4">
                                        <h3>Doctor Name</h3>
                                        <h6 className="fw-normal fst-italic mb-4" style={{ color: "#8cb573" }}>Cardiology Specialist</h6>
                                        <p className="m-0">Dolor lorem eos dolor duo eirmod sea. Dolor sit magna rebum clita rebum dolor</p>
                                    </div>
                                    <div className="d-flex mt-auto border-top p-4">
                                        <a className="btn btn-lg btn-lg-square text-light rounded-circle me-3" style={{ backgroundColor: "#8cb573" }} href="#"><i className="fab fa-twitter" /></a>
                                        <a className="btn btn-lg btn-lg-square text-light rounded-circle me-3" style={{ backgroundColor: "#8cb573" }} href="#"><i className="fab fa-facebook-f" /></a>
                                        <a className="btn btn-lg btn-lg-square text-light rounded-circle" style={{ backgroundColor: "#8cb573" }} href="#"><i className="fab fa-linkedin-in" /></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="team-item">
                            <div className="row g-0 bg-light rounded overflow-hidden">
                                <div className="col-12 col-sm-5 h-100">
                                    <img className="img-fluid h-100" src="img/team-2.jpg" style={{ objectFit: 'cover' }} />
                                </div>
                                <div className="col-12 col-sm-7 h-100 d-flex flex-column">
                                    <div className="mt-auto p-4">
                                        <h3>Doctor Name</h3>
                                        <h6 className="fw-normal fst-italic mb-4" style={{ color: "#8cb573" }}>Cardiology Specialist</h6>
                                        <p className="m-0">Dolor lorem eos dolor duo eirmod sea. Dolor sit magna rebum clita rebum dolor</p>
                                    </div>
                                    <div className="d-flex mt-auto border-top p-4">
                                        <a className="btn btn-lg btn-lg-square text-light rounded-circle me-3" style={{ backgroundColor: "#8cb573" }} href="#"><i className="fab fa-twitter" /></a>
                                        <a className="btn btn-lg btn-lg-square text-light rounded-circle me-3" style={{ backgroundColor: "#8cb573" }} href="#"><i className="fab fa-facebook-f" /></a>
                                        <a className="btn btn-lg btn-lg-square text-light rounded-circle" style={{ backgroundColor: "#8cb573" }} href="#"><i className="fab fa-linkedin-in" /></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="team-item">
                            <div className="row g-0 bg-light rounded overflow-hidden">
                                <div className="col-12 col-sm-5 h-100">
                                    <img className="img-fluid h-100" src="img/team-3.jpg" style={{ objectFit: 'cover' }} />
                                </div>
                                <div className="col-12 col-sm-7 h-100 d-flex flex-column">
                                    <div className="mt-auto p-4">
                                        <h3>Doctor Name</h3>
                                        <h6 className="fw-normal fst-italic mb-4" style={{ color: "#8cb573" }}>Cardiology Specialist</h6>
                                        <p className="m-0">Dolor lorem eos dolor duo eirmod sea. Dolor sit magna rebum clita rebum dolor</p>
                                    </div>
                                    <div className="d-flex mt-auto border-top p-4">
                                        <a className="btn btn-lg btn-lg-square text-light rounded-circle me-3" style={{ backgroundColor: "#8cb573" }} href="#"><i className="fab fa-twitter" /></a>
                                        <a className="btn btn-lg btn-lg-square text-light rounded-circle me-3" style={{ backgroundColor: "#8cb573" }} href="#"><i className="fab fa-facebook-f" /></a>
                                        <a className="btn btn-lg btn-lg-square text-light rounded-circle" style={{ backgroundColor: "#8cb573" }} href="#"><i className="fab fa-linkedin-in" /></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* Team End */}


            {/* Search Start */}
            <div className="container-fluid my-5 py-5" style={{ backgroundColor: "#8cb573" }}>
                <div className="container py-5">
                    <div className="text-center mx-auto mb-5" style={{ maxWidth: 500 }}>
                        <h5 className="d-inline-block text-white text-uppercase border-bottom border-5">Find A Doctor</h5>
                        <h1 className="display-4 mb-4">Find A Healthcare Professionals</h1>
                        <h5 className="text-white fw-normal">Duo ipsum erat stet dolor sea ut nonumy tempor. Tempor duo lorem eos sit sed ipsum takimata ipsum sit est. Ipsum ea voluptua ipsum sit justo</h5>
                    </div>
                    <div className="mx-auto" style={{ width: '100%', maxWidth: 600 }}>
                        <div className="input-group">
                            <select className="form-select border-primary w-25" style={{ height: 60 }}>
                                <option selected>Specialities</option>
                                <option value={1}>Orthopedists</option>
                                <option value={2}>General Surgean</option>
                                <option value={3}>Pysiotheraphists</option>
                            </select>
                            <input type="text" className="form-control border-primary w-50" placeholder="Search" />
                            <button className="btn btn-success border-0 w-25">Search</button>
                        </div>
                    </div>
                </div>
            </div>
            {/* Search End */}



            {/* Testimonial Start */}
            <div className="container-fluid py-5">
                <div className="container">
                    <div className="text-center mx-auto mb-5" style={{ maxWidth: 500 }}>
                        <h5 className="d-inline-block text-uppercase border-bottom border-5" style={{ color: "#8cb573" }}>Testimonial</h5>
                        <h1 className="display-4">Patients Say About Our Services</h1>
                    </div>
                    <div className="row justify-content-center">
                        <div className="col-lg-8">
                            <div className="owl-carousel testimonial-carousel">
                                <div className="testimonial-item text-center">
                                    <div className="position-relative mb-5">
                                        <img className="img-fluid rounded-circle mx-auto" src="img/testimonial-1.jpg" alt />
                                        <div className="position-absolute top-100 start-50 translate-middle d-flex align-items-center justify-content-center bg-white rounded-circle" style={{ width: 60, height: 60 }}>
                                            <i className="fa fa-quote-left fa-2x" style={{ color: "#8cb573" }} />
                                        </div>
                                    </div>
                                    <p className="fs-4 fw-normal">Dolores sed duo clita tempor justo dolor et stet lorem kasd labore dolore lorem ipsum. At lorem lorem magna ut et, nonumy et labore et tempor diam tempor erat. Erat dolor rebum sit ipsum.</p>
                                    <hr className="w-25 mx-auto" />
                                    <h3>Patient Name</h3>
                                    <h6 className="fw-normal mb-3" style={{ color: "#8cb573" }}>Profession</h6>
                                </div>
                                <div className="testimonial-item text-center">
                                    <div className="position-relative mb-5">
                                        <img className="img-fluid rounded-circle mx-auto" src="img/testimonial-2.jpg" alt />
                                        <div className="position-absolute top-100 start-50 translate-middle d-flex align-items-center justify-content-center bg-white rounded-circle" style={{ width: 60, height: 60 }}>
                                            <i className="fa fa-quote-left fa-2x " style={{ color: "#8cb573" }} />
                                        </div>
                                    </div>
                                    <p className="fs-4 fw-normal">Dolores sed duo clita tempor justo dolor et stet lorem kasd labore dolore lorem ipsum. At lorem lorem magna ut et, nonumy et labore et tempor diam tempor erat. Erat dolor rebum sit ipsum.</p>
                                    <hr className="w-25 mx-auto" />
                                    <h3>Patient Name</h3>
                                    <h6 className="fw-normal mb-3" style={{ color: "#8cb573" }}>Profession</h6>
                                </div>
                                <div className="testimonial-item text-center">
                                    <div className="position-relative mb-5">
                                        <img className="img-fluid rounded-circle mx-auto" src="img/testimonial-3.jpg" alt />
                                        <div className="position-absolute top-100 start-50 translate-middle d-flex align-items-center justify-content-center bg-white rounded-circle" style={{ width: 60, height: 60 }}>
                                            <i className="fa fa-quote-left fa-2x" style={{ color: "#8cb573" }} />
                                        </div>
                                    </div>
                                    <p className="fs-4 fw-normal">Dolores sed duo clita tempor justo dolor et stet lorem kasd labore dolore lorem ipsum. At lorem lorem magna ut et, nonumy et labore et tempor diam tempor erat. Erat dolor rebum sit ipsum.</p>
                                    <hr className="w-25 mx-auto" />
                                    <h3>Patient Name</h3>
                                    <h6 className="fw-normal mb-3" style={{ color: "#8cb573" }}>Profession</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* Testimonial End */}



            {/* About Start */}
            <div className="container-fluid py-5">
                <div className="container">
                    <div className="row gx-5">
                        <div className="col-lg-5 mb-5 mb-lg-0" style={{ minHeight: 500 }}>
                            <div className="position-relative h-100">
                                <img className="position-absolute w-100 h-100 rounded" src="img/about-1.jpg" style={{ objectFit: 'cover' }} />
                            </div>
                        </div>
                        <div className="col-lg-7">
                            <div className="mb-4">
                                <h5 className="d-inline-block text-uppercase border-bottom border-5" style={{ color: "#8cb573" }}>About Us</h5>
                                <h1 className="display-4">All The Physical & Medical Care For Yourself and Your Family</h1>
                            </div>
                            <p>Every day, we're helping healthcare providers treat millions of patients as individuals. From specialty diagnostics to the cutting-edge science behind COVID-19, oncology, chronic diseases and more—we’ll never stop delivering better, smarter resources.</p>
                            <div className="row g-3 pt-3">
                                <div className="col-sm-3 col-6">
                                    <div className="bg-light text-center rounded-circle py-4">
                                        <i className="fa fa-3x fa-user-md mb-3" style={{ color: "#8cb573" }} />
                                        <h6 className="mb-0">Qualified<small className="d-block" style={{ color: "#8cb573" }}>Doctors</small></h6>
                                    </div>
                                </div>
                                <div className="col-sm-3 col-6">
                                    <div className="bg-light text-center rounded-circle py-4">
                                        <i className="fa fa-3x fa-procedures mb-3" style={{ color: "#8cb573" }} />
                                        <h6 className="mb-0">Emergency<small className="d-block" style={{ color: "#8cb573" }}>Services</small></h6>
                                    </div>
                                </div>
                                <div className="col-sm-3 col-6">
                                    <div className="bg-light text-center rounded-circle py-4">
                                        <i className="fa fa-3x fa-microscope mb-3" style={{ color: "#8cb573" }} />
                                        <h6 className="mb-0">Accurate<small className="d-block" style={{ color: "#8cb573" }}>Testing</small></h6>
                                    </div>
                                </div>
                                <div className="col-sm-3 col-6">
                                    <div className="bg-light text-center rounded-circle py-4">
                                        <i className="fa fa-3x fa-ambulance mb-3" style={{ color: "#8cb573" }} />
                                        <h6 className="mb-0">Free<small className="d-block" style={{ color: "#8cb573" }}>Ambulance</small></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* About End */}


            {/* Back to Top */}
            <a href="#" className="btn btn-lg text-light btn-lg-square back-to-top" style={{ backgroundColor: "#8cb573" }}><i className="bi bi-arrow-up" /></a>

        </div>

    )
}

export default Dashboard