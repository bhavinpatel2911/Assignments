import { BrowserRouter, Route, Routes } from "react-router-dom";
import Navbar from "./Web-Components/Navbar";
import Dashboard from "./Web-Components/Dashboard";
import Care from "./Web-Components/Care";
import Footer from "./Web-Components/Footer";
import Appointment from "./Web-Components/Appointment";
import Team from "./Web-Components/Team";
import Login from "./Web-Components/Login";
import Register from "./Web-Components/Register";
import { ToastContainer } from 'react-toastify';
import Update from "./Web-Components/Update";
import Admin_login from "./Admin/Admin_login";
import Admin_navbar from "./Admin/Admin_navbar";
import Data from "./Admin/Data";
import Admin_edit from "./Admin/Admin_edit";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route index path="/" element={<><Navbar/><Dashboard/><Footer/></>}></Route>
          <Route path="/Care" element={<><Navbar/><Care/><Footer/></>}></Route>
          <Route path="/Appointment" element={<><Navbar/><Appointment/><Footer/></>}></Route>
          <Route path="/Team" element={<><Navbar/><Team/><Footer/></>}></Route>
          <Route path="/Login" element={<><Navbar/><Login/><Footer/></>}></Route>
          <Route path="/Register" element={<><Navbar/><Register/><Footer/></>}></Route>
          <Route path="/Update" element={<><Navbar/><Update/><Footer/></>}></Route>
          <Route path="/Admin" element={<><Admin_login/></>}></Route>
          <Route path="/Admin_navbar" element={<><Admin_navbar/><Data/></>}></Route>
          <Route path="/Data" element={<><Admin_navbar/><Data/></>}></Route>
          <Route path="/Admin_edit/:id" element={<><Admin_navbar/><Admin_edit/></>}></Route>
        </Routes>
        <ToastContainer/>
      </BrowserRouter>
    </div>
  );
}

export default App;
