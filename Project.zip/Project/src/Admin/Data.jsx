import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'

function Data() {
    let redirect = useNavigate()
    let main_div = {
        height: "auto",
        width: "75%",
        margin: "4% auto"
    }
    // Fatch Data
    let [data, setdata] = useState()
    useEffect(() => {
        fatch()
    }, [])
    let fatch = async () => {
        let res = await axios.get(`http://localhost:8000/user`)
        setdata(res.data)
    }
    // Delete user
    let del=(id)=>{
        if(window.confirm("Are You Sure to Delete ?")){
            axios.delete(`http://localhost:8000/user/${id}`)
            toast.success("User Removed Successfully !")
            fatch()
        }
    }
    return (
        <div className='main_div' style={main_div}>
            <div className='table-responsive'>
                <table className="table table-hover table-bordered border-primary table-responsive.table align-middle">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Address</th>
                            <th scope="col">Contact</th>
                            <th scope="col">Email</th>
                            <th scope="col">Password</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            data && data.map((item) => {
                                return (
                                    <tr>
                                        <td>{item.id}</td>
                                        <td>{item.name}</td>
                                        <td>{item.address}</td>
                                        <td>{item.contact}</td>
                                        <td>{item.email}</td>
                                        <td>{item.password}</td>
                                        <td><button className='btn btn-outline-danger' onClick={()=>{del(item.id)}}>Delete</button><button className='ms-3 btn btn-outline-success' onClick={()=>{redirect("/Admin_edit/"+item.id)}}>Edit</button></td>
                                    </tr>
                                )
                            })
                        }
                    </tbody>
                </table>

            </div>
        </div>
    )
}

export default Data