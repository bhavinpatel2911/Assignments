import React from 'react'
import { NavLink } from 'react-router-dom'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'

function Admin_navbar() {
    let redirect=useNavigate()
    let logout=()=>{
        if(window.confirm("Are you Sure to Logout ?")){
            localStorage.removeItem('id')
            redirect('/')
            toast.success("Logout Successfull !")
        }
    }
    return (
        <div>
            {/* Navbar Start */}
            <div className="container-fluid sticky-top bg-white shadow-sm">
                <div className="container">
                    <nav className="navbar navbar-expand-lg bg-white navbar-light py-3 py-lg-0">
                        <NavLink to='/' className="navbar-brand">
                            <h1 className="m-0 text-uppercase" style={{ color: "#ffb347" }}><img src="logo.png" style={{ height: "70px" }} alt="" />Admin Panel</h1>
                        </NavLink>
                        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                            <span className="navbar-toggler-icon" />
                        </button>
                        <div className="collapse navbar-collapse" id="navbarCollapse">
                            <div className="navbar-nav ms-auto py-0">
                                <NavLink to='/Data' className="nav-item nav-link">User Data</NavLink>
                                <NavLink to='/Care' className="nav-item nav-link">Add Doctor</NavLink>
                                <NavLink to='/Appointment' className="nav-item nav-link">Manage Appointment</NavLink>
                                <NavLink to='/Team' className="nav-item nav-link">Logout</NavLink>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
            {/* Navbar End */}
        </div>

    )
}

export default Admin_navbar