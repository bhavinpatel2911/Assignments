import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'

function Admin_login() {
    let redirect=useNavigate()
    let main_style={
        height:"450px",
        width:"40%",
        margin:"5% auto",
        boxShadow: "rgba(0, 0, 0, 0.35) 0px 5px 15px"
    }
    let [formdata,setformdata]=useState({
        email:"",
        password:""
    })
    let onchange=(e)=>{
        setformdata({...formdata,[e.target.name]:e.target.value})
    }
    let login=(e)=>{
        e.preventDefault()
        if(formdata.email=="admin@gmail.com" && formdata.password=="bhavin@2911"){
            redirect('/Admin_navbar')
            toast.success("Welcome Bhavin Patel !")
        }
        else{
            toast.error("Authentication Required !")
        }
    }
  return (
    <div className='main' style={main_style}>
        <h1 style={{textAlign:"center",paddingTop:"5%"}}>Login Here !</h1>
          <form className='mt-5 ms-5 me-5'>
              <div className="mb-3">
                  <label htmlFor="exampleInputEmail1" className="form-label">Email address</label>
                  <input type="email" name='email' value={formdata.email} onChange={onchange} className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" autoComplete='off' required/>
                  <div id="emailHelp" className="form-text">We'll never share your email with anyone else.</div>
              </div>
              <div className="mb-3">
                  <label htmlFor="exampleInputPassword1" className="form-label">Password</label>
                  <input type="password" name='password' value={formdata.password} onChange={onchange}  className="form-control" id="exampleInputPassword1" required/>
              </div>
              <div className="mb-3 form-check">
                  <input type="checkbox" className="form-check-input" id="exampleCheck1" />
                  <label className="form-check-label" htmlFor="exampleCheck1">Check me out</label>
              </div>
              <button type="submit" className="btn btn-success" onClick={login}>Login</button>
          </form>

    </div>
  )
}

export default Admin_login