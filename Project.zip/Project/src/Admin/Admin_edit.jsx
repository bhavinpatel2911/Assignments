import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from 'react-router-dom';


function Admin_edit() {

    // Fatch Data

    let id=localStorage.getItem('id')
    useEffect(()=>{
        fatch()
    },[])
    let fatch=async()=>{
        let res=await axios.get(`http://localhost:8000/user/${id}`)
        setformdata(res.data)
    }

    // Update Data
    let redirect=useNavigate()
    let [formdata, setformdata] = useState({
        id: "",
        name: "",
        address: "",
        email: "",
        contact: "",
        password: ""
    })
    let onchange = (e) => {
        setformdata({ ...formdata, [e.target.name]: e.target.value })
    }
    let onsubmit = async(e) => {
        e.preventDefault()
        await axios.patch(`http://localhost:8000/user/${id}`, formdata)
        .then((res)=>{
            if(res.status==200){
                toast.success("Updated Successfull !")
                setformdata({...formdata,name:"",address:"",email:"",contact:"",password:""})    
                redirect('/')
            }
        })
    }
    return (
        <div>
            <div className="col-lg-4" style={{ margin: "1% auto", boxShadow: "#8cb573 0px 0px 1px 1px" }}>
                <div className="bg-white text-center rounded p-5">
                    <h1 className="mb-4">Update Data !</h1>
                    <form>
                        <div className="row g-3">
                            <div className="col-12 col-sm-6" style={{ width: "100%" }}>
                                <input type="text" className="form-control bg-light border-0" placeholder="Your Name" value={formdata.name} onChange={onchange} style={{ height: 55 }} name='name' />
                            </div>
                            <div className="col-12 col-sm-6" style={{ width: "100%" }}>
                                <input type="text" className="form-control bg-light border-0" placeholder="Your Address" value={formdata.address} onChange={onchange} style={{ height: 80 }} name='address' />
                            </div>
                            {/* <div className="col-12 col-sm-6" style={{width:"55%"}}>
                                            <label htmlFor="gender">Gender:</label>
                                            <input type="radio" className='ms-3' name="gender" id="male" value={"Male"}/><label htmlFor='male'>Male</label>
                                            <input type="radio" className='ms-3' name="gender" id="female" value={"female"}/><label htmlFor='female'>Female</label>
                                        </div> */}
                            <div className="col-12 col-sm-6" style={{ width: "100%" }}>
                                <input type="email" className="form-control bg-light border-0" placeholder="Your Email" value={formdata.email} onChange={onchange} style={{ height: 55 }} name='email' />
                            </div>
                            <div className="col-12 col-sm-6" style={{ width: "100%" }}>
                                <input type="text" className="form-control bg-light border-0" placeholder="Your Contact" value={formdata.contact} onChange={onchange} style={{ height: 55 }} name='contact' />
                            </div>
                            <div className="col-12 col-sm-6" style={{ width: "100%" }}>
                                <input type="password" className="form-control bg-light border-0" placeholder="Your Password" value={formdata.password} onChange={onchange} style={{ height: 55 }} name='password' />
                            </div>
                            <div className="col-12">
                                <button className="btn w-100 py-3 text-light" style={{ backgroundColor: "#8cb573" }} type="submit" onClick={onsubmit}>Update</button>
                            </div>
                        </div>
                        <Link className='mt-1' to='/Login' style={{ float: "left" }}>All Ready Registed ? Login Here !</Link>
                    </form>
                </div>
            </div>
        </div>
    )
}

export default Admin_edit